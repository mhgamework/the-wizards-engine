#include <w32api/GL/gl.h>
#include <w32api/GL/glu.h>
/*
#ifdef __CYGWIN32__
#define APIENTRY
#define CALLBACK
#define WINGDIAPI __attribute__ ((__stdcall__))
#endif
#include <GL/glut.h>
*/
/*
#ifdef _MSC_VER
#include <windows.h>
#undef APIENTRY
#undef WINGDIAPI
#define APIENTRY __cdecl
#define WINGDIAPI
#pragma comment (lib, "opengl32.lib")  /* link with Microsoft OpenGL lib */
//#pragma comment (lib, "glu32.lib")     /* link with Microsoft OpenGL Utility lib */
//#endif

//#include <GL/gl.h>
